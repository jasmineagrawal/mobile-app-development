package com.example.a1bm17cs123;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class activityB extends AppCompatActivity {
private Intent intent;
File myfile;
String filepath="SDcard";
String filename="student.txt";
    String name,usn,email;
    private Button confirm;
private TextView t_name,t_usn,t_email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
        t_name=(TextView)findViewById(R.id.t_name);
        t_usn=(TextView)findViewById(R.id.t_usn);
        t_email=(TextView)findViewById(R.id.t_email);
        confirm=(Button)findViewById(R.id.confirm);


        intent=getIntent();
        name=intent.getStringExtra("name");
        usn=intent.getStringExtra("usn");
        email=intent.getStringExtra("email");

        t_name.setText(name);
        t_usn.setText(usn);
        t_email.setText(email);

        if(!isExternalStorageAvailable() || isExternalStorageReadOnly())
        {
            confirm.setEnabled(false);
        }
        else
            myfile=new File(getExternalFilesDir(filepath),filename);

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    String message="\nName "+name+"\nusn "+usn +"\nemail "+email;
                    FileOutputStream fout=new FileOutputStream(myfile);
                    fout.write(message.getBytes());
                    fout.close();
                    Toast.makeText(getApplicationContext(), "Written into SD card", Toast.LENGTH_SHORT).show();


                }
                catch(Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    return;

                }

            }
        });




    }


    private boolean isExternalStorageReadOnly() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) {
            return true;
        }
        return false;
    }

    private boolean isExternalStorageAvailable() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(extStorageState)) {
            return true;
        }
        return false;
    }
}
