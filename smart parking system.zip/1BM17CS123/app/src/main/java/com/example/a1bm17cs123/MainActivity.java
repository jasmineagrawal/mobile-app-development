package com.example.a1bm17cs123;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
private Button submit;
private EditText name,usn,email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        submit=(Button)findViewById(R.id.submit);
        name=(EditText)findViewById(R.id.name);
        usn=(EditText)findViewById(R.id.usn);
        email=(EditText)findViewById(R.id.email);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate())
                {
                    Intent intent=new Intent(MainActivity.this,activityB.class);
                    intent.putExtra("name",name.getText().toString().trim());
                    intent.putExtra("usn",usn.getText().toString().trim());
                    intent.putExtra("email",email.getText().toString().trim());
                    startActivity(intent);

                }




            }
        });

    }


    private boolean validate() {
        if (email.getText().toString().trim().equals("") || usn.getText().toString().trim().equals("") ||
                name.getText().toString().trim().equals("")) {
            Toast.makeText(getApplicationContext(), "enter all the fields", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (email.getText().toString().indexOf("@") < 0) {
            Toast.makeText(getApplicationContext(), "wrong email", Toast.LENGTH_SHORT).show();
            return false;
        }


        if (!(name.getText().toString().trim().matches("^[a-zA-Z]*$"))) {

            Toast.makeText(getApplicationContext(), "enter the proper name", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!(usn.getText().toString().trim().matches("^[1][A-Z]{2}[1-9]{2}[A-Z]{2}[0-9]{3}$")))

        {
            Toast.makeText(getApplicationContext(), "enter the proper usn", Toast.LENGTH_SHORT).show();
            return false;

        }
        return true;
    }

}
